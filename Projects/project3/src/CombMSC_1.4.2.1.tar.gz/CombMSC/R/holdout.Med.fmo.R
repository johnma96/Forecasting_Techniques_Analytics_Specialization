`holdout.Med.fmo` <-
function(object, ...) holdout.Med(object$train, test.Frame = object$test.Frame, 
  test.Vector = object$test.Vector)

