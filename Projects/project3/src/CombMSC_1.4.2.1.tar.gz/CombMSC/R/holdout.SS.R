`holdout.SS` <-
function(object, ...)UseMethod("holdout.SS")

