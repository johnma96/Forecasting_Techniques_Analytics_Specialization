`Adj.Rsq.fmo` <-
function(object, ...) Adj.Rsq(object$full)

