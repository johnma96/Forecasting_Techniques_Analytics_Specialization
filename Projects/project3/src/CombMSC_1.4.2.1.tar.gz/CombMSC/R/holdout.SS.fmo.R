`holdout.SS.fmo` <-
function(object, ...) holdout.SS(object$train, test.Frame = object$test.Frame,
  test.Vector = object$test.Vector)

