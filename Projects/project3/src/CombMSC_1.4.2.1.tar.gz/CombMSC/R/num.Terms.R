`num.Terms` <-
function(object, ...)UseMethod("num.Terms")

