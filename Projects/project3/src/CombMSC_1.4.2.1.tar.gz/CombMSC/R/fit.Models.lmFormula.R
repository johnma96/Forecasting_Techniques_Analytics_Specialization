`fit.Models.lmFormula` <-
function(fmla, data.Vector, train.Frame, ...){
  lm(formula = fmla, data=train.Frame)
}

