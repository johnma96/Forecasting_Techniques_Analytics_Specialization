`BIC.fmo` <-
function(object, ...)AIC(object$full, k = log(length(object$full$res)))

