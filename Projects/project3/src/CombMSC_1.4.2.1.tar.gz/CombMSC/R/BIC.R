`BIC` <-
function(object, ...)UseMethod("BIC")

