`Cp` <-
function(object, a = 1, b = 0, ...) UseMethod("Cp", object)

