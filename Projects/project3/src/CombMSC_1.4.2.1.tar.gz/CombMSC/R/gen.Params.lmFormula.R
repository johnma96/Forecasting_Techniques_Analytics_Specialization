`gen.Params.lmFormula` <-
function(fmla, mu=0, par.Sigma, var.Frame = var.Frame, ...)
 rnorm(n= num.Terms(fmla), mean = mu, sd = par.Sigma)

