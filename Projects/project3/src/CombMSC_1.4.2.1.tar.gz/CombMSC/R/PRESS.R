`PRESS` <-
function(object, ...) UseMethod("PRESS")

