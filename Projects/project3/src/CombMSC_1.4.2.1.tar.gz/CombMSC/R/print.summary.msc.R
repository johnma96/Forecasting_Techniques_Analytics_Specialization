`print.summary.msc` <-
function(x, ...){
  print(x$Corners)
  print(x$Minima)
}

