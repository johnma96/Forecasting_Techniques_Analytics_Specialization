`Cp.fmo` <-
function(object, a = 1, b = 0, ...) Cp(object$full, a = a, b = b, S2 = object$S2)

