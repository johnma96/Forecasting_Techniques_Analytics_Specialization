`fit.Models` <-
function(fmla, ...)UseMethod("fit.Models")

