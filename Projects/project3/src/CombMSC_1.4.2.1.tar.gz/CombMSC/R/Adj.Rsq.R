`Adj.Rsq` <-
function(object, ...) UseMethod("Adj.Rsq")

