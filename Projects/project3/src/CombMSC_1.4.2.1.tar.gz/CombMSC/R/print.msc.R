`print.msc` <-
function(x, ...){print(x$call); print(names(x))}

