`holdout.Med` <-
function(object, ...)UseMethod("holdout.Med")

