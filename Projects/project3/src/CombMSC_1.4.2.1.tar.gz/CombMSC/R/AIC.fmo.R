`AIC.fmo` <-
function(object, ..., k = 2)AIC(object$full, k = k)

