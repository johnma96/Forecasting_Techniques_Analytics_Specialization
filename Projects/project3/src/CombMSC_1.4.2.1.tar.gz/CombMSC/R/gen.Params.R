`gen.Params` <-
function(fmla, ...)UseMethod("gen.Params")

