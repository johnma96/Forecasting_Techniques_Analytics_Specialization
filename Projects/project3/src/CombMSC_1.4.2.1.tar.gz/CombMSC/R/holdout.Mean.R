`holdout.Mean` <-
function(object, ...)UseMethod("holdout.Mean")

