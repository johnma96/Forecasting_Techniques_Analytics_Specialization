`holdout.Mean.fmo` <-
function(object, ...) holdout.Mean(object$train, test.Frame = object$test.Frame,
  test.Vector = object$test.Vector)

