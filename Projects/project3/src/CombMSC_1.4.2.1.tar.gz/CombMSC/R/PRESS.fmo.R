`PRESS.fmo` <-
function(object, ...) PRESS(object$full)

