`gen.Data` <-
function(fmla, ...)UseMethod("gen.Data")

