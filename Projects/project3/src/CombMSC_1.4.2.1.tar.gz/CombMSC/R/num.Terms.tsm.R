`num.Terms.tsm` <-
function(object, ...)sum(object$model$AR, object$model$MA, object$seasonal$model$AR, object$seasonal$model$MA)

